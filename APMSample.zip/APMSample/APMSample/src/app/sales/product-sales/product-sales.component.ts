import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-product-sales',
  templateUrl: './product-sales.component.html',
  styleUrls: ['./product-sales.component.css']
})
export class ProductSalesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
