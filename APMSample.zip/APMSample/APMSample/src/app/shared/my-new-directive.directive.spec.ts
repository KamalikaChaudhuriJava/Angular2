import { MyNewDirectiveDirective } from './my-new-directive.directive';

describe('MyNewDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MyNewDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
