import { Directive } from '@angular/core';

@Directive({
  selector: '[pmMyNewDirective]'
})
export class MyNewDirectiveDirective {

  constructor() { }

}
