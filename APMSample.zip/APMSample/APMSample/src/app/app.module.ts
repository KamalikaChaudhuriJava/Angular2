import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import {FormsModule} from '@angular/forms';
import { ProductListComponent } from './products/product-list.component';
import { MyNewPipePipe } from './shared/my-new-pipe.pipe';
import { MyNewDirectiveDirective } from './shared/my-new-directive.directive';
import { MyNewComponentComponent } from './shared/my-new-component/my-new-component.component';

import { ConvertospacePipe } from './shared/convertospace.pipe';


@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    MyNewPipePipe,
    MyNewDirectiveDirective,
    MyNewComponentComponent,
   
    ConvertospacePipe,
  
   
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
}) 
export class AppModule { }
